# Changelog

## 2.5.31

Bug fix for wackydb_all_items

## 2.5.30

Updated for the Valheim 1.07 release.

Added support for SE_SET_Equips for all slots.

Added `NonPlayer` damage support.

Added the `Hidden` field to status effects.

Added item fields `m_upgradeChance`, `m_breakChance`, `m_successUpgradeSteps`, and `m_breakReturnIngreientsAmount`.

Added recipe fields `m_listSortWeight` and `m_noCraftOnlyUpgrade`; custom upgrade recipes now preserve both native settings.

Added piece fields `allowedInDeepSnow`, `requireDeepSnow`, `spaceRequirement`, `repairPiece`, `isUpgrade`, `usage`, `blockingPieces`, and `canRockJade`.

Added WearNTear fields `snowDamageImmune`, `outsideRequiredBiomeDamage`, and `minToolTier`.

Added the CraftingStation `upgrader` field.

Documented all available piece `usage` categories and support for combining usage flags.

## 2.5.22

Added support for SE_SET_Equips to count right-hand, left-hand, and utility slots.

## 2.5.21

Moved AOES and projectiles right after SE's load and now wackydb waits to load all gameobjects until after AOEs complete.

## 2.5.20

Bug fix for searching all objects in AOEs

## 2.5.19

Moved AOES and projectiles earlier in reload

## 2.5.18

Bug fix

## 2.5.17

Added ReapplyCooldown to SEs

## 2.5.16

Added SE_SET_Equips and HideEquipEffectsUntilSetComplete

## 2.5.15

Fix for CheckWard

## 2.5.14

Changed a Warning (Something went wrong in file) to an Error

Added mockBasePrefab to items for the mock system. This allows you to specify your mock as a "clone" of different vanilla prefab.

## 2.5.13

Added Saftety checks to piece clones to prevent duplicates.

Transpiler patch for InventoryGui CanRepair for recipes that repairs past quality level 5 min.

## 2.5.12

Fixed the bug for upgrade recipe showing other recipes when a material from it is picked up.

Made the maxStationLevelCap a bit more robust.

Changed how ServerSync Reloads are stored. When a second one comes in before the first one completes, it will be queued and processed.

## 2.5.11

Bug Fix

## 2.5.00

You asked for it for years. Wacky delivered. Projectile and Aoe support added.

Bug fix for creature materials.

## 2.4.97

Bug fix for SE StartEffects/StopEffects being null, now they are just empty on new SEs. - lol

## 2.4.96

Removed the old SE StartEffects/StopEffects and made sure it was null for new SEs.

## 2.4.95

Hardened the recipe logic to minimize duplication.

Rewrote piece snapshot manager again. This time it should not break and drop items.

## 2.4.94

Added ammoType to Items. (Useful for custom tankards and some weapons).

## 2.4.93

Fixed asset-sync and connection issues.

## 2.4.92

Piece build now requires `-` to delete all build requirements.

Runs `wackydb_reload` automatically after asset sync.

Restored the old piece snapshot.

## 2.4.91

Reenabled serversync for large asset transfers.

## 2.4.90

Rewrote a lot of the logic for live updates.

Improved piece snapshot handling.

Send the Load now triggers after a player logs in. No need to include the textures anymore.

piece build is now not required for pieces to preserve cost.

## 2.4.83

Added lots of null guards for weird null pieces.

## 2.4.82

Bug fix second hit dmg.

## 2.4.81

Bug fix for Creature saving.

## 2.4.80

Bug fix for Feast name/description change/tooltip for Serving Tray.

## 2.4.79

Finally fixed a long standing bug for Item_CrossbowArbalest. It may have affected other items as well.

## 2.4.78

Vanilla game bug fix for last chain hit mod

## 2.4.77

Made it so ( "hammer", "HAMMER", "Hammer") wackydb_all_pieces command

## 2.4.76

Bug fix

## 2.4.75

Added "delete" option for custom icons in SEs.

## 2.4.74

More logs for wackydb_sendtheload

## 2.4.73

Bug Fix for some Materials.

Rewrote the piece moving category logic a bit to reduce bugs.

Worked on wackydb_sendtheload, should now handle texture sending and alert the admin when done. It also does  WackyDB_AssetRequest so that client only requests data it doesn't have. Please test

## 2.4.72

Reduced the amount of Recipe_Recipe (Actual Recipes) in wackydb_all_recipe significantly.

Fix for modded items showing their crafting stations in recipe name.

Added some compatibility for modded effect search and list.

## 2.4.71

wackydb_reload bug fix, light optimization.

## 2.4.70

The request has been fulfilled, you can now sort pieces. Added categoryOrderBeforePrefab to Pieces. This allows you to specifically place your pieces before another piece, in a relative order for categories. You can chain up to 100 pieces. (A before B, B before C).

Spacing fix for SE.

Removed Json converter and all old json related code.

Updated SE Localization and material logs are hidden by isDebugString config

## 2.4.67

Added m_blockStaminaUseFlatValue for ADC_Support_Urgot

Updated LocalizationManager and PieceManager

## 2.4.66

Health", "Stamina", and "Eitr will be localized for AddHP, AddStamina, and AddEit

## 2.4.65

Updated Readme

Added StaffRedTroll to item exception list for full stats

Made is so short SE's don't give warning.

Fix for m_staminaUpFront

bug fix for custom speed override for Secondary

Rewrote some material rendered code to be more efficient.

Fix for Projectile_Accuracy spelling (old will still work). Added new field Projectile_Accuracy_Min.

## 2.4.64

Bug Fix.

## 2.4.62

Percent Damage Modifiers Percentage m_percentDamageModifiers added to SEs.

## 2.4.61

Added a check that prevents the player from going below 1HP from the SE health. You can still die, but not because the admin owner was dumb. Well.. you can still die from a dumb admin

## 2.4.60

Your cries have been heard and answered. I have added addHP, addStamina, addEitr to SEs. You can now make SEs add base stats! You can also make them negative. - Yes it adds mores patches (same patches as epicmmo), but they are minor and don't run if you don't use any.

Also added SlightlyResistant to wet, same as Resistant.

Will remove the old json conversion soon. Not that anyone is still using wackydb 1.0, but here is your last chance to upgrade.

## 2.4.58

Update to allow non cloned pieces to become craftingstations.

## 2.4.57

Added New stuff from 221.4. Resave YMLs to see new fields.

SE fields:  m_heatlhUpFront,m_staminaUpFront, m_eitrUpFront. m_adrenalineUpFront,m_adrenalineModifier, m_staggerModifier, m_staggerTimeBlockBonus, m_armorAdd, m_armorMultiplier

New to Items: blockable, AdrenalineStats: maxAdrenaline fullAdrenalineSE,blockAdrenaline,perfectBlockAdrenaline .  Shields:m_perfectBlockStaminaRegen, m_perfectBlockStatusEffect, m_buildBlockCharges,m_maxBlockCharges,m_blockChargeDecayTime. To Food: eatAnimationTime, isDrink. ToAttack: is_HomeItem, m_attackAdrenaline, m_attackUseAdrenaline, attack_Health_Low_BlockUsage, cant_Use_InDungeon.

Updated TranslationManager.

## 2.4.56

Added SeFrost and SePoison. Also added - `m_attackStaminaUseModifier, m_blockStaminaUseModifier, m_dodgeStaminaUseModifier, m_swimStaminaUseModifier, m_homeItemStaminaUseModifier, m_sneakStaminaUseModifier, m_runStaminaUseModifier for SEs

## 2.4.55

Added EndingStatusEffect to SE's, you can now chain SEs together. Don't forget to use Category.

Updated ServerSync.

## 2.4.54

Added burnable to WearnTear.

## 2.4.53

Added Display Normal Logs config. If you want to turn off most of wackydb logs. You shouldn't do this unless you have a good reason. ie 1000+ yamls

Removed comfortObject and replaced with comfortObjectName.

Lowered some warnings to just info logs.

## 2.4.52

Fixed Tooltip for Water

## 2.4.51

Update 220.3 and ServerSync update. Fixed a startup error on Game Pass crossplay.

## 2.4.50

Added ShieldGenData

Added BatteringRamData

Okay, IÃ¢â‚¬â„¢ve had some questions about icons being in folders over the past few weeks. You can specify the relative file path of the icon. For example, if your icon is in the folder `Icons/Items/wacky.png`, just use `"Items/wacky.png"`. Will revealing the "secret" forward slash come back to haunt me? Absolutely.

## 2.4.48

ConsumableStatusEffect can now be deleted with `delete`.

Added materialType to WearNTear on pieces, allowing the piece material and support strength to be changed.

## 2.4.47

Added Feast editing feastStacks to FoodStats. Feasts have a Item and Piece component and then an another _Material item. Most people should just edit the normal Item. Can't clone because they are too complicated.

Added ashlandProof to ships(pieces) (Majestic request)

Added SE cache(ing) for mods like MonsterDB.

Added AppendToolTip to items. It's not used too much, but essential when needed (mostly foods)(ignore this for feasts)

Cleaned up some code.

## 2.4.46

Minor bug fix for extra resource consumption with recipes.

## 2.4.45

Expanded saving Attack classes for non attack items that still have important fields. Like Hoe and Shields.

## 2.4.44

Bug fix for cSExtensionDataList

## 2.4.43

Update for PieceManager

## 2.4.42

Bug fix.

## 2.4.41

Bog The Witch Update

Add support for multiple Piece CSExtensionData. You can now also make (almost) any piece into an extension for a craftingstation.

Added support for Pieces to become craftingstations.

Added Pickable m_extraDrops stuff

Removed unnecessary warning for disabled pieces.

Added Hit_Friendly to attack

## 2.4.31

Expanded upgrade_reqs for recipes levels!  You can now specify completely different recipes for all upgrades. Rejoice, no more hacks.

## 2.4.28

Renamed a field to Damage_Multiplier_By_Health_Deficit_Percent

Updated Readme with some (light) video tutorial links.

## 2.4.27

Fix for Primary/Secondary Status Effect.

Added `Attack_Start_Noise`(float),       `Attack_Hit_Noise`(float),        `Dmg_Multiplier_Per_Missing_Health`(float),        `Dmg_Multiplier_Per_Total_Health`(float), `Stamina_Return_Per_Missing_HP`(float),     `SelfDamage`(int), `Attack_Kills_Self`(bool)

## 2.4.26

Fix for rare unarmed attack causing error and no dmg.

## 2.4.25

Coop sync fix

Rewrote how 'ExtraSecurity on Servers' works. Should sync from Servers to clients better now.

Send logs for any issues

## 2.4.24

PerBurst_Resource_usage bug fix.

## 2.4.23

Updated PerBurst_Resource_usage and Destroy_Previous_Projectile for misspellings. If you use these, please regenerate your yaml files or rename fields, otherwise can be ignored.

Bug fixes for pickables with other plant mods.

## 2.4.22

Bug fixes for materials.

AlanDrake added filterMode to textures for advanced texturing.

## 2.4.21

Incoming Big Update sponsored by Lughbaloo: Pickables and Plants!

PlantData is saved in pieces, which point to either Pickable or Treebase when matured. When you pick a pickable it becomes an item. You can of course clone and change size/material. Enjoy this wacky expansion.

## 2.4.13

Bug fix for attack_status_effect

## 2.4.12

Rexabyte fix for darker textures than intended. Also you can now save materials with spaces in the name, using underscores '_ | _Material item. Most people should just edit the normal Item. Can't clone because they are too complicated.

Added ashlandProof to ships(pieces) (Majestic request)

Added SE cache(ing) for mods like MonsterDB.

Added AppendToolTip to items. It's not used too much, but essential when needed (mostly foods)(ignore this for feasts)

Cleaned up some code.

## 2.4.11

Added 'delete' to spawn_on_hit and spawn_on_terrain_hit for items.

Added command to save all mobs wackydb_all_creatures in Bulk Folder

Separated out attack_status_effect into primary and secondary, custom wackydb patch for it. The normal attack_status_effect will be overwritten if a primary or secondary is set.

Added m_jumpModifier as a Vector3. Unnecessary lines can be deleted.

Added some more logs for debugmode

IG forgot to add a check for zero stamina for staminaReload, added

## 2.3.9

Added Attack_status_effect_chance

Fixed COOP servers again. I even verfied with Gamepass PC.

## 2.3.8

Added SE/se to wackydb_clone, rejoice, you can now change which SE you clone. Allows you to clone SEShield now.

Added the ability to delete Attack_status_effect with "delete"

## 2.3.7

Changed disabled recipes code again

Added back ReloadTime, might work for some things.

Added Reload_Eitr_Drain

Fix for DedServer load Memory = false.

Added Reset_Chain_If_hit, SpawnOnHit, SpawnOnHit_Chance, Raise_Skill_Amount, Skill_Hit_Type, Special_Hit_Skill, Special_Hit_Type to Attack.

Added Attach_Override for items

## 2.3.6

Possible bug fix for disabled recipes.

## 2.3.5

Bug fixes for recipes, disabled and disabledUpgrade

Bug fix for double serversync issue, was probably causing server admins a lot of problems on pushing updates without restarts.

Changed singleplayer loading yml files to be more consistent with how multiplayer client receives them. Required fields are required.

Removed unnecessarily log on respawn

## 2.3.4

Bug Fix for recipe.

## 2.3.3

Added values for Staff of protection SE or SE Staff_

Updated PieceManager

Officially added upgrade_reqs and disabledUpgrade for Recipe goodness. Say thank you to Blaxx and Item Manager

Added warning if Recipes don't find req item

Fixed using actual recipes like Recipe_Bronze5

Added notOnWood for pieces

## 2.3.1

Adjust font sizeMin for Categories.

Added AllowAllItems for portal Pieces

Added Fireplace for pieces - Infinite Fuel now

Fixed Mock System again.

## 2.3.0

Update for Ashlands.

Removed m_baseItemsStaminaModifier, added a lot of other StaminaModfiers.

Updated PieceManager

## 2.2.6

Removed Reloadtime(broken) and replaced it with ReloadTimeMultiplier for crossbow.

## 2.2.5

Added snapshotRotation and snapshotOnMaterialChange for items.

Fix for some cloned pieces

Fix for reloading RecipeMaxStationLvl

Added incineratorData conversion for obliterator, you can now make obliterator into a recycler if you want.

## 2.2.2

Bug Fix for SE_Effects with generated PLUS effects

## 2.2.1

Added BaseItemStamina for statmods

Add StaffSkelton attack

Fix Bug on PLUS effects

## 2.2.0

Decent sized Update: Fix for cloned creatures replacing main creatures name

Enabled piece snapshot again, hopefully it works well this time. Added a command wackydb_snapshot for pieces

Vastly expanded effect capabilities. Old Effects will work, but generate new yamls for more features.

Added Remove to piece conversion list allows you to disable an input and not forcing me to clear the whole list. Now the list shouldn't conflict with additional mods.

## 2.1.7

Update Readme a bit.

Made it so some pieces didn't reload twice.

## 2.1.6

Bug fix for cloned pieces on relog.

Thx to OrianaVenture for updated icon

## 2.1.5

Added API for Clone mapping to orginal prefab.

Adjustment for Epicloot+wackydb on quitting

## 2.1.4

Happy Halloween, this update is for the spooky people that use "," as decimal delimiters, resulting in crazy big sizes of items/pieces.

SizeMultiplier is now seperated with \ |

Updated a Priority for loading

## 2.1.3

Added custom SS messsage back

added a 4th layer to piece search

Separated out sizeMultiplier for x,y,z or just one value

Added a check for transplier at closeout for a few people that hang.

Updated Refs for new Bepinex

Changed loading order again

## 2.1.2

Updated recipeGet, Removed recipe quality (it's a good idea, but I didn't like how it was implemented**).**

Took out my custom ServerSync temporarily to test a bug, it won't display message 0.0.1

## 2.1.1

Change a priorty.

Minimized the chance of a recipe consuming double resources with cfc. It will still happen with cfc, if a recipe has quality of > 1

## 2.1.0

Bug fix, changed color on messages from lime to red

## 2.0.9

Bug Fix

## 2.0.8

Updated ServerSync, Piecemanger, Patch update for 217.24

Fix bug for recipes consuming resources twice.

## 2.0.7

Fixed effects not following you.

Add beehive data to pieces.

Fix for dedicated servers not loading data. Moved up reload for dedicated servers.

Changed log messages, added more warnings.

Added more checks for cloned cache.

Fix for mock items.

## 2.0.6

Big bug fix for servers. Moved main loading to an even later point. Added SizeMultiplier to cache, for extra sized cached weapons.

## 2.0.5

Bug fix for a cache item error on updateitemhash.

## 2.0.4

Added ConsumableStatusEffect to items.

Hovernames for cloned doors.

Added Sap and Fermentor Section to pieces.

BIG - Moved main loading to a later point for more pieces to be found.

Reduced bug counts with disabling pieces.

Known bug: moving from one hammer to another hammer, might require disabling orginal and cloning.

Fixed Mock items for the adventurous few, added example for mock bike.

## 2.0.3

Bug fix for cloned items being deleted for some people.  Fix for piece disabling, disabling already placed pieces - whoops

## 2.0.2

Bug fix for cloned pieces being deleted at logout and login -sorry

## 2.0.1

First Release of 2.0

## 2.0.0

2.0.0 - Lots of betas

